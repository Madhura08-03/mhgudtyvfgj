%% ============================================================
% M6_CreateMockEnvironment.m
% Task 2 - Standalone Mock Environment
%
% Creates deterministic mock inputs for:
%   1. PerceptionBus
%   2. DecisionBus
%
% Initial scenario:
%   Ego vehicle starts at [0, 0]
%   Tractor at [40, 0]
%   Cow at [80, -1.5]
%% ============================================================

clear mockPerception mockDecision

%% -----------------------------
% Configuration
%% -----------------------------

MAX_TARGETS = 10;

%% -----------------------------
% Mock Perception Data
%% -----------------------------

mockPerception.TargetIDs = zeros(MAX_TARGETS,1,'uint32');

mockPerception.TargetPositions = zeros(MAX_TARGETS,3);

mockPerception.TargetVelocities = zeros(MAX_TARGETS,2);

mockPerception.ClassIDs = zeros(MAX_TARGETS,1,'uint8');

mockPerception.PredictedPaths = zeros(MAX_TARGETS,30,2);

%% Tractor
mockPerception.TargetIDs(1) = uint32(1);

mockPerception.TargetPositions(1,:) = [40 0 0];

mockPerception.TargetVelocities(1,:) = [0 0];

mockPerception.ClassIDs(1) = uint8(1);

%% Cow
mockPerception.TargetIDs(2) = uint32(2);

mockPerception.TargetPositions(2,:) = [80 -1.5 0];

mockPerception.TargetVelocities(2,:) = [0 0];

mockPerception.ClassIDs(2) = uint8(2);

%% -----------------------------
% Mock Decision Data
%% -----------------------------

mockDecision.ManeuverState = uint8(1);

mockDecision.TargetSpeed = 10;

mockDecision.DecelCmd = 0;

mockDecision.ReplanRequest = false;

%% -----------------------------
% Display Verification
%% -----------------------------

disp('==========================================')
disp('M6 MOCK ENVIRONMENT CREATED SUCCESSFULLY')
disp('==========================================')

disp('Tractor Position:')
disp(mockPerception.TargetPositions(1,:))

disp('Cow Position:')
disp(mockPerception.TargetPositions(2,:))

disp('Target Speed:')
disp(mockDecision.TargetSpeed)