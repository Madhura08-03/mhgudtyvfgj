pathConfig = struct;

pathConfig.ResampleDistance = 1.0;
pathConfig.SmoothingWindow = 5;

pathConfig.MaxSpeed = 10.0;
pathConfig.MaxLateralAcceleration = 3.0;

pathConfig.StartSpeed = 0;
pathConfig.EndSpeed = 0;

disp('M6 PATH PROCESSING CONFIG LOADED')