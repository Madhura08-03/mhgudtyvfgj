%% ============================================================
% M6_RunCompleteValidation.m
%
% Complete standalone runner for M6 validation
%
% This script:
%   1. Configures MATLAB paths
%   2. Loads M6 configurations
%   3. Creates mock environment
%   4. Loads reference path
%   5. Creates planning environment
%   6. Generates occupancy map
%   7. Creates required planner variables
%   8. Runs M6Execution
%   9. Runs final integrated validation
%
% ============================================================

clc;

fprintf('\n');
fprintf('====================================================\n');
fprintf('       M6 COMPLETE VALIDATION RUNNER\n');
fprintf('====================================================\n');


%% ============================================================
% STEP 1 - CONFIGURE PATHS
% ============================================================

% This script must be saved in the M6 root folder

m6Root = fileparts(mfilename('fullpath'));

if isempty(m6Root)
    m6Root = pwd;
end

functionsFolder = fullfile(m6Root,'functions');

addpath(m6Root);
addpath(functionsFolder);

fprintf('\n[1/9] MATLAB paths configured\n');


%% ============================================================
% STEP 2 - LOAD CONTROLLER CONFIGURATION
% ============================================================

run(fullfile(m6Root,'M6_ControllerConfig.m'));

fprintf('\n[2/9] Controller configuration loaded\n');


%% ============================================================
% STEP 3 - LOAD PLANNER CONFIGURATION
% ============================================================

run(fullfile(m6Root,'M6_PlannerConfig.m'));

fprintf('\n[3/9] Planner configuration loaded\n');


%% ============================================================
% STEP 4 - LOAD PATH PROCESSING CONFIGURATION
% ============================================================

run(fullfile(m6Root,'M6_PathProcessingConfig.m'));

fprintf('\n[4/9] Path processing configuration loaded\n');


%% ============================================================
% STEP 5 - CREATE MOCK ENVIRONMENT
% ============================================================

run(fullfile(m6Root,'M6_CreateMockEnvironment.m'));

fprintf('\n[5/9] Mock environment created\n');


%% ============================================================
% STEP 6 - LOAD REFERENCE PATH
% ============================================================

run(fullfile(m6Root,'M6_LoadReferencePath.m'));

fprintf('\n[6/9] Reference path loaded\n');


%% ============================================================
% STEP 7 - CREATE PLANNING ENVIRONMENT
% ============================================================

% ------------------------------------------------------------
% Start state from reference path
% ------------------------------------------------------------

startState = [ ...
    referencePath.X(1), ...
    referencePath.Y(1), ...
    referencePath.Heading(1)];


% ------------------------------------------------------------
% Goal state from reference path
% ------------------------------------------------------------

goalState = [ ...
    referencePath.X(end), ...
    referencePath.Y(end), ...
    referencePath.Heading(end)];


% ------------------------------------------------------------
% Convert mock perception targets into obstacle structure
% ------------------------------------------------------------

obstacles = struct( ...
    'Position', {}, ...
    'Velocity', {}, ...
    'ClassID', {});

obstacleIndex = 0;

for i = 1:length(mockPerception.TargetIDs)

    if mockPerception.TargetIDs(i) ~= 0

        obstacleIndex = obstacleIndex + 1;

        obstacles(obstacleIndex).Position = ...
            mockPerception.TargetPositions(i,1:2);

        obstacles(obstacleIndex).Velocity = ...
            mockPerception.TargetVelocities(i,:);

        obstacles(obstacleIndex).ClassID = ...
            mockPerception.ClassIDs(i);

    end

end


% ------------------------------------------------------------
% Build occupancy map
% ------------------------------------------------------------

egoState = startState;

[occMap,mapInfo] = ...
    buildLocalOccupancyMap( ...
    egoState, ...
    obstacles);


% ------------------------------------------------------------
% Generate path required by validation
% ------------------------------------------------------------

[path,planningSuccess,plannerStats] = ...
    planHybridAStar( ...
    occMap, ...
    mapInfo, ...
    startState, ...
    goalState, ...
    plannerConfig);


if ~planningSuccess

    error( ...
        'M6 planning environment setup failed: Hybrid A* could not generate a path.');

end


fprintf('\n[7/9] Planning environment created\n');

fprintf('Initial planning time: %.6f s\n', ...
    plannerStats.PlanningTime);

fprintf('Generated path points: %d\n', ...
    size(path,1));


%% ============================================================
% STEP 8 - RUN SIMULINK MODEL
% ============================================================

fprintf('\n[8/9] Running M6Execution simulation...\n');

load_system('M6Execution');

out = sim('M6Execution');

fprintf('Simulation completed successfully\n');


%% ============================================================
% STEP 9 - RUN FINAL VALIDATION
% ============================================================

fprintf('\n[9/9] Running final integrated validation...\n');

M6_FinalIntegratedValidation;


fprintf('\n');
fprintf('====================================================\n');
fprintf('       M6 COMPLETE VALIDATION FINISHED\n');
fprintf('====================================================\n');