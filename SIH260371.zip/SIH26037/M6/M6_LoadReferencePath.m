% ============================================================
% M6_LoadReferencePath
%
% Loads processed Hybrid A* reference path for M6Execution.
% ============================================================

load('M6_ReferencePath.mat','referencePath');

referenceX = referencePath.X;
referenceY = referencePath.Y;
referenceHeading = referencePath.Heading;
referenceSpeed = referencePath.TargetSpeed;

disp('==========================================')
disp('M6 REFERENCE PATH LOADED')
disp('==========================================')

fprintf('Reference points: %d\n',length(referenceX));