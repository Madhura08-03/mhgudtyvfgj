function [steeringCmd, crossTrackError, headingError, nearestIndex] = ...
    stanleyController(egoState, referencePath, config)
% ============================================================
% stanleyController
%
% Stanley path-following controller.
%
% INPUT:
%   egoState:
%       [X Y Heading Speed]
%
%   referencePath:
%       X
%       Y
%       Heading
%
%   config:
%       Gain
%       MaxSteeringAngle
%
% OUTPUT:
%   steeringCmd
%   crossTrackError
%   headingError
%   nearestIndex
% ============================================================

%% Ego state

egoX = egoState(1);
egoY = egoState(2);
egoHeading = egoState(3);
egoSpeed = egoState(4);

%% Reference path

refX = referencePath.X(:);
refY = referencePath.Y(:);
refHeading = referencePath.Heading(:);

%% Find nearest path point

distanceSquared = ...
    (refX - egoX).^2 + ...
    (refY - egoY).^2;

[~, nearestIndex] = min(distanceSquared);

%% Reference point

nearestX = refX(nearestIndex);
nearestY = refY(nearestIndex);

referenceHeading = ...
    refHeading(nearestIndex);

%% Heading error

headingError = atan2( ...
    sin(referenceHeading - egoHeading), ...
    cos(referenceHeading - egoHeading));

%% Cross-track error

dx = egoX - nearestX;
dy = egoY - nearestY;

% Signed perpendicular distance
crossTrackError = ...
    -sin(referenceHeading) * dx + ...
    cos(referenceHeading) * dy;

%% Stanley control law

speedSafe = max(abs(egoSpeed),0.1);

steeringCmd = ...
    headingError + ...
    atan( ...
    config.StanleyGain * crossTrackError / ...
    speedSafe);

%% Steering saturation

steeringCmd = max( ...
    -config.MaxSteeringAngle, ...
    min( ...
    config.MaxSteeringAngle, ...
    steeringCmd));

end