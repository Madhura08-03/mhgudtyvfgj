function [accelerationCmd, speedError] = ...
    longitudinalController(egoSpeed, targetSpeed, decelCmd, config)
% ============================================================
% longitudinalController
%
% Speed controller for the autonomous car.
%
% INPUTS
%   egoSpeed       - Current vehicle speed (m/s)
%   targetSpeed    - Desired vehicle speed (m/s)
%   decelCmd       - Requested deceleration command
%   config         - Controller configuration
%
% OUTPUTS
%   accelerationCmd - Requested longitudinal acceleration (m/s^2)
%   speedError      - Target speed tracking error (m/s)
% ============================================================

%% Speed tracking error

speedError = targetSpeed - egoSpeed;

%% Proportional speed control

speedControl = config.SpeedGain * speedError;

%% Apply requested deceleration

accelerationCmd = speedControl - decelCmd;

%% Acceleration saturation

accelerationCmd = max( ...
    config.MaxDeceleration, ...
    min(config.MaxAcceleration, accelerationCmd));

end