function obstacles = parsePerceptionBus(perception)
% ============================================================
% parsePerceptionBus
%
% Converts PerceptionBus data into a clean obstacle structure.
%
% INPUT:
%   perception - structure matching PerceptionBus
%
% OUTPUT:
%   obstacles - structure containing active obstacles
% ============================================================

MAX_TARGETS = length(perception.TargetIDs);

% Preallocate output
obstacles = struct( ...
    'ID', {}, ...
    'Position', {}, ...
    'Velocity', {}, ...
    'ClassID', {});

count = 0;

for i = 1:MAX_TARGETS

    % ID = 0 means unused target slot
    if perception.TargetIDs(i) ~= 0

        count = count + 1;

        obstacles(count).ID = perception.TargetIDs(i);

        obstacles(count).Position = ...
            perception.TargetPositions(i,1:2);

        obstacles(count).Velocity = ...
            perception.TargetVelocities(i,:);

        obstacles(count).ClassID = ...
            perception.ClassIDs(i);

    end

end

end