%% ============================================================
% HYBRID A* 10-RUN PLANNING TIME BENCHMARK
% ============================================================

clc;

numRuns = 10;

planningTimes = zeros(numRuns,1);
iterations = zeros(numRuns,1);
nodesExpanded = zeros(numRuns,1);
successFlags = false(numRuns,1);

fprintf('\n');
fprintf('========================================\n');
fprintf('HYBRID A* 10-RUN PLANNING TIME BENCHMARK\n');
fprintf('========================================\n\n');

%% ------------------------------------------------------------
% Warm-up Run
% Excluded from benchmark
% ------------------------------------------------------------

fprintf('Performing warm-up run...\n');

[~, ~, ~] = planHybridAStar( ...
    occMap, ...
    mapInfo, ...
    startState, ...
    goalState, ...
    plannerConfig);

fprintf('Warm-up complete.\n\n');

%% ------------------------------------------------------------
% Run Benchmark 10 Times
% ------------------------------------------------------------

for run = 1:numRuns

    fprintf('Running benchmark %d/%d...\n', ...
        run, numRuns);

    tStart = tic;

    [path, success, plannerStats] = ...
        planHybridAStar( ...
        occMap, ...
        mapInfo, ...
        startState, ...
        goalState, ...
        plannerConfig);

    elapsedTime = toc(tStart);

    planningTimes(run) = elapsedTime;

    iterations(run) = ...
        plannerStats.Iterations;

    nodesExpanded(run) = ...
        plannerStats.NodesExpanded;

    successFlags(run) = success;

    fprintf('Planning Time: %.6f s\n', ...
        elapsedTime);

    fprintf('Iterations: %d\n', ...
        plannerStats.Iterations);

    fprintf('Nodes Expanded: %d\n\n', ...
        plannerStats.NodesExpanded);

end

%% ============================================================
% CALCULATE BENCHMARK RESULTS
% ============================================================

averagePlanningTime = mean(planningTimes);
minimumPlanningTime = min(planningTimes);
maximumPlanningTime = max(planningTimes);
stdPlanningTime = std(planningTimes);

averageIterations = mean(iterations);
averageNodesExpanded = mean(nodesExpanded);

successfulRuns = sum(successFlags);

%% ============================================================
% DISPLAY RESULTS
% ============================================================

fprintf('\n');
fprintf('========================================\n');
fprintf('HYBRID A* PLANNING TIME BENCHMARK RESULTS\n');
fprintf('========================================\n\n');

fprintf('Number of Runs: %d\n\n', numRuns);

fprintf('PLANNING TIME\n');
fprintf('----------------------------------------\n');

fprintf('Average Planning Time: %.6f seconds\n', ...
    averagePlanningTime);

fprintf('Minimum Planning Time: %.6f seconds\n', ...
    minimumPlanningTime);

fprintf('Maximum Planning Time: %.6f seconds\n', ...
    maximumPlanningTime);

fprintf('Standard Deviation: %.6f seconds\n', ...
    stdPlanningTime);

fprintf('Average Planning Time: %.3f ms\n\n', ...
    averagePlanningTime * 1000);

fprintf('SEARCH PERFORMANCE\n');
fprintf('----------------------------------------\n');

fprintf('Average Iterations: %.1f\n', ...
    averageIterations);

fprintf('Average Nodes Expanded: %.1f\n\n', ...
    averageNodesExpanded);

fprintf('PLANNING SUCCESS\n');
fprintf('----------------------------------------\n');

fprintf('Successful Runs: %d/%d\n', ...
    successfulRuns, numRuns);

fprintf('\n========================================\n');

%% ============================================================
% DISPLAY INDIVIDUAL RUN RESULTS
% ============================================================

fprintf('\nINDIVIDUAL RUN RESULTS\n');
fprintf('========================================\n');

for run = 1:numRuns

    fprintf( ...
        'Run %2d | Time: %.6f s | Iterations: %5d | Nodes: %5d | Success: %d\n', ...
        run, ...
        planningTimes(run), ...
        iterations(run), ...
        nodesExpanded(run), ...
        successFlags(run));

end

fprintf('========================================\n');