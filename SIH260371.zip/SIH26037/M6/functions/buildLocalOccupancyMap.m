function [occMap, mapInfo] = buildLocalOccupancyMap( ...
    egoState, obstacles)
% ============================================================
% buildLocalOccupancyMap
%
% Creates a local 2D occupancy grid around the ego vehicle.
%
% Current initial configuration:
%   Map size:       100 m × 40 m
%   Resolution:     2 cells/m
%   Ego-centered
%   Road:           traversable
%   Outside road:   occupied
%   Obstacles:      occupied
%
% INPUT:
%   egoState [X Y Heading]
%   obstacles - output from parsePerceptionBus
%
% OUTPUT:
%   occMap  - binary occupancy matrix
%   mapInfo - metadata needed for coordinate conversion
% ============================================================

%% Map configuration

mapLength = 140;      % meters
mapWidth  = 40;       % meters

resolution = 2;       % cells per meter

numRows = mapWidth * resolution;
numCols = mapLength * resolution;

%% Initialize map

% 0 = free
% 1 = occupied

occMap = zeros(numRows, numCols);

%% Map origin

% Local map centered around ego laterally
% Ego placed 20 m behind the front edge

mapInfo.Resolution = resolution;

mapInfo.OriginX = egoState(1) - 20;
mapInfo.OriginY = egoState(2) - mapWidth/2;

mapInfo.Length = mapLength;
mapInfo.Width = mapWidth;

%% Define road

roadWidth = 8;     % meters

roadMinY = -roadWidth/2;
roadMaxY = roadWidth/2;

% Convert global Y limits to grid rows

for row = 1:numRows

    globalY = mapInfo.OriginY + ...
        (row - 0.5)/resolution;

    localY = globalY - egoState(2);

    if localY < roadMinY || localY > roadMaxY

        % Outside road is occupied
        occMap(row,:) = 1;

    end

end

%% Add obstacles

obstacleRadius = 1.5;  % meters

for i = 1:length(obstacles)

    obsX = obstacles(i).Position(1);
    obsY = obstacles(i).Position(2);

    % Convert obstacle global coordinates to grid coordinates

    colCenter = round( ...
        (obsX - mapInfo.OriginX) * resolution);

    rowCenter = round( ...
        (obsY - mapInfo.OriginY) * resolution);

    radiusCells = ceil(obstacleRadius * resolution);

    % Circular obstacle footprint

    for r = rowCenter-radiusCells : rowCenter+radiusCells

        for c = colCenter-radiusCells : colCenter+radiusCells

            if r >= 1 && r <= numRows && ...
               c >= 1 && c <= numCols

                distance = sqrt( ...
                    (r-rowCenter)^2 + ...
                    (c-colCenter)^2);

                if distance <= radiusCells

                    occMap(r,c) = 1;

                end

            end

        end

    end

end

end