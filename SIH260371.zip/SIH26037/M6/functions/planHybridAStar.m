function [path, success, plannerStats] = planHybridAStar( ...
    occMap, mapInfo, startState, goalState, plannerConfig)
% ============================================================
% Faster Hybrid A* Local Path Planner
% Optimized Open List Implementation
%
% State: [x y heading]
% ============================================================

tStart = tic;

success = false;
path = [];

plannerStats.Iterations = 0;
plannerStats.NodesExpanded = 0;
plannerStats.PlanningTime = 0;

%% ============================================================
% Configuration
%% ============================================================

stepLength = plannerConfig.XStep;
wheelbase = plannerConfig.Wheelbase;
steeringSamples = plannerConfig.SteeringSamples;

maxIterations = plannerConfig.MaxIterations;
numHeadingBins = plannerConfig.NumHeadingBins;

positionTolerance = plannerConfig.GoalTolerancePosition;
headingTolerance = plannerConfig.GoalToleranceHeading;

[numRows, numCols] = size(occMap);

%% ============================================================
% Cost Storage
%
% Best cost for:
% Row × Column × Heading Bin
%% ============================================================

bestCost = inf(numRows, numCols, numHeadingBins);

%% ============================================================
% Node Storage
%% ============================================================

nodeTemplate = struct( ...
    'State', [0 0 0], ...
    'Parent', 0, ...
    'G', inf, ...
    'F', inf);

nodes = nodeTemplate;

%% ============================================================
% Start Node
%% ============================================================

startRow = floor( ...
    (startState(2) - mapInfo.OriginY) * ...
    mapInfo.Resolution) + 1;

startCol = floor( ...
    (startState(1) - mapInfo.OriginX) * ...
    mapInfo.Resolution) + 1;

startHeadingBin = localHeadingBin( ...
    startState(3), ...
    numHeadingBins);

%% ============================================================
% Check Start Position
%% ============================================================

if startRow < 1 || startRow > numRows || ...
   startCol < 1 || startCol > numCols

    plannerStats.PlanningTime = toc(tStart);
    return

end

%% ============================================================
% Initialize Start Node
%% ============================================================

nodes(1).State = startState;
nodes(1).Parent = 0;
nodes(1).G = 0;

nodes(1).F = localHeuristic( ...
    startState, ...
    goalState);

bestCost( ...
    startRow, ...
    startCol, ...
    startHeadingBin) = 0;

%% ============================================================
% Open List
%
% openList contains node indices.
% openF stores corresponding F-costs.
%
% This avoids rebuilding the complete F-cost vector
% during every search iteration.
%% ============================================================

openList = 1;
openF = nodes(1).F;

goalNodeIndex = 0;

%% ============================================================
% Hybrid A* Search
%% ============================================================

while ~isempty(openList) && ...
      plannerStats.Iterations < maxIterations

    plannerStats.Iterations = ...
        plannerStats.Iterations + 1;

    % --------------------------------------------------------
    % Find Node With Lowest F-Cost
    % --------------------------------------------------------

    [~, bestIndex] = min(openF);

    currentIndex = openList(bestIndex);

    % Remove selected node from open list

    openList(bestIndex) = [];
    openF(bestIndex) = [];

    currentNode = nodes(currentIndex);

    plannerStats.NodesExpanded = ...
        plannerStats.NodesExpanded + 1;

    % --------------------------------------------------------
    % Goal Check
    % --------------------------------------------------------

    positionError = norm( ...
        currentNode.State(1:2) - ...
        goalState(1:2));

    headingError = abs( ...
        localAngleDifference( ...
        currentNode.State(3), ...
        goalState(3)));

    if positionError <= positionTolerance && ...
       headingError <= headingTolerance

        success = true;

        goalNodeIndex = currentIndex;

        break

    end

    % --------------------------------------------------------
    % Expand Steering Primitives
    % --------------------------------------------------------

    for s = 1:length(steeringSamples)

        steering = steeringSamples(s);

        % ----------------------------------------------------
        % Propagate Vehicle State
        % ----------------------------------------------------

        nextState = localPropagateState( ...
            currentNode.State, ...
            steering, ...
            stepLength, ...
            wheelbase);

        % ----------------------------------------------------
        % Convert State To Grid Coordinates
        % ----------------------------------------------------

        nextCol = floor( ...
            (nextState(1) - mapInfo.OriginX) * ...
            mapInfo.Resolution) + 1;

        nextRow = floor( ...
            (nextState(2) - mapInfo.OriginY) * ...
            mapInfo.Resolution) + 1;

        % ----------------------------------------------------
        % Check Map Boundary
        % ----------------------------------------------------

        if nextRow < 1 || ...
           nextRow > numRows || ...
           nextCol < 1 || ...
           nextCol > numCols

            continue

        end

        % ----------------------------------------------------
        % Collision Check
        % ----------------------------------------------------

        if occMap(nextRow, nextCol) > 0.5

            continue

        end

        % ----------------------------------------------------
        % Heading Bin
        % ----------------------------------------------------

        nextHeadingBin = localHeadingBin( ...
            nextState(3), ...
            numHeadingBins);

        % ----------------------------------------------------
        % Cost Calculation
        % ----------------------------------------------------

        turnCost = abs(steering) * ...
            plannerConfig.TurnWeight;

        gNew = currentNode.G + ...
            stepLength + ...
            turnCost;

        % ----------------------------------------------------
        % Skip State If Reached With Lower Cost
        % ----------------------------------------------------

        if gNew >= bestCost( ...
                nextRow, ...
                nextCol, ...
                nextHeadingBin)

            continue

        end

        % ----------------------------------------------------
        % Update Best Cost
        % ----------------------------------------------------

        bestCost( ...
            nextRow, ...
            nextCol, ...
            nextHeadingBin) = gNew;

        % ----------------------------------------------------
        % Heuristic Cost
        % ----------------------------------------------------

        hNew = localHeuristic( ...
            nextState, ...
            goalState);

        % ----------------------------------------------------
        % Total Cost
        % ----------------------------------------------------

        fNew = gNew + hNew;

        % ----------------------------------------------------
        % Create New Node
        % ----------------------------------------------------

        newNode = nodeTemplate;

        newNode.State = nextState;
        newNode.Parent = currentIndex;

        newNode.G = gNew;
        newNode.F = fNew;

        % ----------------------------------------------------
        % Add Node
        % ----------------------------------------------------

        nodes(end+1) = newNode;

        newNodeIndex = length(nodes);

        openList(end+1) = newNodeIndex;

        % Store F-cost directly in parallel vector

        openF(end+1) = fNew;

    end

end

%% ============================================================
% Reconstruct Path
%% ============================================================

if success

    indices = [];

    currentIndex = goalNodeIndex;

    while currentIndex ~= 0

        indices(end+1) = currentIndex;

        currentIndex = ...
            nodes(currentIndex).Parent;

    end

    indices = fliplr(indices);

    path = zeros(length(indices), 3);

    for k = 1:length(indices)

        path(k,:) = ...
            nodes(indices(k)).State;

    end

end

%% ============================================================
% Store Planning Time
%% ============================================================

plannerStats.PlanningTime = toc(tStart);

end


%% ============================================================
% Local Function:
% Propagate Vehicle State
%% ============================================================

function nextState = localPropagateState( ...
    state, steering, stepLength, wheelbase)

x = state(1);
y = state(2);
heading = state(3);

nextHeading = heading + ...
    stepLength * tan(steering) / wheelbase;

nextHeading = atan2( ...
    sin(nextHeading), ...
    cos(nextHeading));

nextX = x + ...
    stepLength * cos(heading);

nextY = y + ...
    stepLength * sin(heading);

nextState = [ ...
    nextX ...
    nextY ...
    nextHeading];

end


%% ============================================================
% Local Function:
% Convert Heading To Heading Bin
%% ============================================================

function headingBin = localHeadingBin( ...
    heading, numHeadingBins)

heading = atan2( ...
    sin(heading), ...
    cos(heading));

headingNormalized = ...
    (heading + pi) / (2 * pi);

headingBin = floor( ...
    headingNormalized * numHeadingBins) + 1;

headingBin = max( ...
    1, ...
    min(numHeadingBins, headingBin));

end


%% ============================================================
% Local Function:
% Heuristic
%% ============================================================

function h = localHeuristic( ...
    state, goalState)

positionDistance = norm( ...
    state(1:2) - ...
    goalState(1:2));

headingDifference = abs( ...
    localAngleDifference( ...
    state(3), ...
    goalState(3)));

h = positionDistance + ...
    0.5 * headingDifference;

end


%% ============================================================
% Local Function:
% Angle Difference
%% ============================================================

function difference = ...
    localAngleDifference(a, b)

difference = atan2( ...
    sin(a - b), ...
    cos(a - b));

end