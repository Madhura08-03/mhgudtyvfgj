function referencePath = processReferencePath(path, config)
% ============================================================
% processReferencePath
%
% Converts the raw Hybrid A* path into a processed reference
% path suitable for path-following and speed control.
%
% INPUT:
%   path   - N x 3 [x y heading]
%   config - path processing configuration structure
%
% OUTPUT:
%   referencePath structure containing:
%       X
%       Y
%       Heading
%       Curvature
%       TargetSpeed
%       PathDistance
% ============================================================


%% 1. REMOVE DUPLICATE CONSECUTIVE POSITIONS

xy = path(:,1:2);

keep = [true; vecnorm(diff(xy),2,2) > 1e-6];

path = path(keep,:);


%% Handle very short paths

if size(path,1) < 2

    referencePath.X = path(:,1);
    referencePath.Y = path(:,2);
    referencePath.Heading = path(:,3);
    referencePath.Curvature = zeros(size(path,1),1);
    referencePath.TargetSpeed = ...
        config.EndSpeed * ones(size(path,1),1);
    referencePath.PathDistance = zeros(size(path,1),1);

    return

end


%% 2. CALCULATE CUMULATIVE PATH DISTANCE

segmentLength = sqrt( ...
    diff(path(:,1)).^2 + ...
    diff(path(:,2)).^2);

s = [0; cumsum(segmentLength)];

totalLength = s(end);


%% 3. UNIFORM PATH RESAMPLING

spacing = config.ResampleDistance;

sQuery = (0:spacing:totalLength)';

if sQuery(end) < totalLength

    sQuery(end+1) = totalLength;

end


xRef = interp1( ...
    s, ...
    path(:,1), ...
    sQuery, ...
    'linear');

yRef = interp1( ...
    s, ...
    path(:,2), ...
    sQuery, ...
    'linear');


%% 4. PATH SMOOTHING

smoothWindow = config.SmoothingWindow;

% Window must be odd
if mod(smoothWindow,2) == 0

    smoothWindow = smoothWindow + 1;

end

% Prevent window from exceeding path size
smoothWindow = min(smoothWindow,length(xRef));

if mod(smoothWindow,2) == 0

    smoothWindow = smoothWindow - 1;

end

if smoothWindow >= 3

    xSmooth = movmean(xRef,smoothWindow);
    ySmooth = movmean(yRef,smoothWindow);

else

    xSmooth = xRef;
    ySmooth = yRef;

end


%% 5. CALCULATE PATH HEADING

dx = gradient(xSmooth);

dy = gradient(ySmooth);

headingRef = atan2(dy,dx);

headingRef = unwrap(headingRef);


%% 6. CALCULATE CURVATURE

ddx = gradient(dx);

ddy = gradient(dy);

denominator = ...
    (dx.^2 + dy.^2).^(3/2);

denominator = max(denominator,1e-6);

curvature = ...
    (dx .* ddy - dy .* ddx) ./ denominator;


%% 7. GENERATE CURVATURE-BASED SPEED PROFILE

maxSpeed = config.MaxSpeed;

maxLateralAcceleration = ...
    config.MaxLateralAcceleration;

speedProfile = sqrt( ...
    maxLateralAcceleration ./ ...
    max(abs(curvature),1e-4));

speedProfile = min(speedProfile,maxSpeed);


%% 8. START AND END SPEED CONSTRAINTS

speedProfile(1) = ...
    min(speedProfile(1),config.StartSpeed);

speedProfile(end) = ...
    min(speedProfile(end),config.EndSpeed);


%% OUTPUT

referencePath.X = xSmooth;

referencePath.Y = ySmooth;

referencePath.Heading = headingRef;

referencePath.Curvature = curvature;

referencePath.TargetSpeed = speedProfile;

referencePath.PathDistance = sQuery;

end