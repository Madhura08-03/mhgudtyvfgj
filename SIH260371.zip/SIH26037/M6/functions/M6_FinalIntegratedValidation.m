%% ============================================================
% M6_FinalIntegratedValidation.m
%
% Final Integrated Validation for M6 Autonomous Vehicle Pipeline
%
% Validates:
%   1. Hybrid A* Path Planning Performance
%   2. Path Tracking Performance
%   3. Longitudinal Speed Tracking
%   4. Steering Command Limits
%   5. Acceleration / Deceleration Limits
%   6. Final Vehicle State
%
% ============================================================

clc;

fprintf('\n');
fprintf('====================================================\n');
fprintf('       M6 FINAL INTEGRATED VALIDATION RESULTS\n');
fprintf('====================================================\n');


%% ============================================================
% CHECK SIMULATION OUTPUT
% ============================================================

if ~exist('out','var')

    error('Simulation output variable "out" does not exist. Run M6Execution first.');

end


%% ============================================================
% CHECK PLANNING VARIABLES
% ============================================================

if ~exist('occMap','var')

    error('occMap does not exist. Run the environment setup first.');

end

if ~exist('mapInfo','var')

    error('mapInfo does not exist. Run the environment setup first.');

end

if ~exist('startState','var')

    error('startState does not exist.');

end

if ~exist('goalState','var')

    error('goalState does not exist.');

end

if ~exist('plannerConfig','var')

    error('plannerConfig does not exist. Run M6_PlannerConfig first.');

end


%% ============================================================
% HYBRID A* PATH PLANNING PERFORMANCE VALIDATION
% ============================================================

numPlanningRuns = 10;

planningTimes = zeros(numPlanningRuns,1);

planningIterations = zeros(numPlanningRuns,1);

planningNodesExpanded = zeros(numPlanningRuns,1);

planningSuccessFlags = false(numPlanningRuns,1);


% ------------------------------------------------------------
% Warm-Up Run
% ------------------------------------------------------------

[~, ~, ~] = planHybridAStar( ...
    occMap, ...
    mapInfo, ...
    startState, ...
    goalState, ...
    plannerConfig);


% ------------------------------------------------------------
% Benchmark Hybrid A*
% ------------------------------------------------------------

for run = 1:numPlanningRuns

    [~, planningSuccess, plannerStats] = ...
        planHybridAStar( ...
        occMap, ...
        mapInfo, ...
        startState, ...
        goalState, ...
        plannerConfig);

    planningTimes(run) = ...
        plannerStats.PlanningTime;

    planningIterations(run) = ...
        plannerStats.Iterations;

    planningNodesExpanded(run) = ...
        plannerStats.NodesExpanded;

    planningSuccessFlags(run) = ...
        planningSuccess;

end


% ------------------------------------------------------------
% Planning Performance Metrics
% ------------------------------------------------------------

averagePlanningTime = ...
    mean(planningTimes);

minimumPlanningTime = ...
    min(planningTimes);

maximumPlanningTime = ...
    max(planningTimes);

stdPlanningTime = ...
    std(planningTimes);

averagePlanningIterations = ...
    mean(planningIterations);

averageNodesExpanded = ...
    mean(planningNodesExpanded);

successfulPlanningRuns = ...
    sum(planningSuccessFlags);


%% ============================================================
% PATH PLANNING PERFORMANCE THRESHOLD
% ============================================================

% Maximum acceptable average planning time

maxAllowedPlanningTime = 1.0;


% Planning must succeed in all runs

planningSuccessPass = ...
    successfulPlanningRuns == numPlanningRuns;


planningTimePass = ...
    averagePlanningTime <= ...
    maxAllowedPlanningTime;


pathPlanningPass = ...
    planningSuccessPass && ...
    planningTimePass;


%% ============================================================
% EXTRACT SIMULATION DATA
% ============================================================

time = out.tout(:);

egoX = out.egoXLog(:);
egoY = out.egoYLog(:);

egoSpeed = out.egoSpeedLog(:);

targetSpeed = out.targetSpeedLog(:);

steeringCmd = out.steeringCmdLog(:);

accelerationCmd = out.accelerationCmdLog(:);

heading = out.headingLog(:);


%% ============================================================
% ALIGN SIGNAL LENGTHS
% ============================================================

N = min([ ...
    length(time), ...
    length(egoX), ...
    length(egoY), ...
    length(egoSpeed), ...
    length(targetSpeed), ...
    length(steeringCmd), ...
    length(accelerationCmd), ...
    length(heading)]);

time = time(1:N);

egoX = egoX(1:N);
egoY = egoY(1:N);

egoSpeed = egoSpeed(1:N);
targetSpeed = targetSpeed(1:N);

steeringCmd = steeringCmd(1:N);

accelerationCmd = accelerationCmd(1:N);

heading = heading(1:N);


%% ============================================================
% PATH TRACKING VALIDATION
% ============================================================

if ~exist('path','var')

    error('Reference path variable "path" does not exist.');

end


refX = path(:,1);
refY = path(:,2);


crossTrackError = zeros(N,1);

nearestPathIndex = zeros(N,1);


for i = 1:N

    distanceSquared = ...
        (refX - egoX(i)).^2 + ...
        (refY - egoY(i)).^2;

    [minimumDistanceSquared, nearestIndex] = ...
        min(distanceSquared);

    crossTrackError(i) = ...
        sqrt(minimumDistanceSquared);

    nearestPathIndex(i) = nearestIndex;

end


maxCrossTrackError = ...
    max(crossTrackError);

rmsCrossTrackError = ...
    sqrt(mean(crossTrackError.^2));

finalCrossTrackError = ...
    crossTrackError(end);


%% ============================================================
% LONGITUDINAL SPEED TRACKING VALIDATION
% ============================================================

speedError = ...
    targetSpeed - egoSpeed;


maxSpeedError = ...
    max(abs(speedError));

rmsSpeedError = ...
    sqrt(mean(speedError.^2));

finalSpeedError = ...
    speedError(end);


%% ============================================================
% CONTROL COMMAND VALIDATION
% ============================================================

maxSteeringCommand = ...
    max(abs(steeringCmd));


maxAccelerationCommand = ...
    max(accelerationCmd);


maxDecelerationCommand = ...
    min(accelerationCmd);


%% ============================================================
% FINAL VEHICLE STATE
% ============================================================

finalX = egoX(end);

finalY = egoY(end);

finalSpeed = egoSpeed(end);

finalHeading = heading(end);


%% ============================================================
% CONTROL LIMITS
% ============================================================

maxAllowedAcceleration = 3.0;

maxAllowedDeceleration = -5.0;

maxAllowedSteering = 0.6;


%% ============================================================
% VALIDATION CHECKS
% ============================================================

steeringLimitPass = ...
    maxSteeringCommand <= ...
    maxAllowedSteering;


accelerationLimitPass = ...
    maxAccelerationCommand <= ...
    maxAllowedAcceleration + 1e-6;


decelerationLimitPass = ...
    maxDecelerationCommand >= ...
    maxAllowedDeceleration - 1e-6;


%% ============================================================
% PERFORMANCE THRESHOLDS
% ============================================================

maxAllowedFinalCrossTrackError = 1.0;

maxAllowedFinalSpeedError = 0.1;


pathTrackingPass = ...
    finalCrossTrackError <= ...
    maxAllowedFinalCrossTrackError;


speedTrackingPass = ...
    abs(finalSpeedError) <= ...
    maxAllowedFinalSpeedError;


%% ============================================================
% OVERALL VALIDATION STATUS
% ============================================================

overallPass = ...
    pathPlanningPass && ...
    pathTrackingPass && ...
    speedTrackingPass && ...
    steeringLimitPass && ...
    accelerationLimitPass && ...
    decelerationLimitPass;


%% ============================================================
% PRINT PATH PLANNING RESULTS
% ============================================================

fprintf('\n');

fprintf('----------------------------------------------------\n');
fprintf('HYBRID A* PATH PLANNING PERFORMANCE\n');
fprintf('----------------------------------------------------\n');

fprintf('Planning Runs: %d\n', ...
    numPlanningRuns);

fprintf('Successful Planning Runs: %d/%d\n', ...
    successfulPlanningRuns, ...
    numPlanningRuns);

fprintf('Average Planning Time: %.6f s\n', ...
    averagePlanningTime);

fprintf('Average Planning Time: %.3f ms\n', ...
    averagePlanningTime * 1000);

fprintf('Minimum Planning Time: %.6f s\n', ...
    minimumPlanningTime);

fprintf('Maximum Planning Time: %.6f s\n', ...
    maximumPlanningTime);

fprintf('Planning Time Standard Deviation: %.6f s\n', ...
    stdPlanningTime);

fprintf('Average Iterations: %.1f\n', ...
    averagePlanningIterations);

fprintf('Average Nodes Expanded: %.1f\n', ...
    averageNodesExpanded);


%% ============================================================
% PRINT PATH TRACKING RESULTS
% ============================================================

fprintf('\n');

fprintf('----------------------------------------------------\n');
fprintf('PATH TRACKING PERFORMANCE\n');
fprintf('----------------------------------------------------\n');

fprintf('Maximum Cross-Track Error: %.3f m\n', ...
    maxCrossTrackError);

fprintf('RMS Cross-Track Error: %.3f m\n', ...
    rmsCrossTrackError);

fprintf('Final Cross-Track Error: %.3f m\n', ...
    finalCrossTrackError);


%% ============================================================
% PRINT LONGITUDINAL RESULTS
% ============================================================

fprintf('\n');

fprintf('----------------------------------------------------\n');
fprintf('LONGITUDINAL SPEED TRACKING\n');
fprintf('----------------------------------------------------\n');

fprintf('Maximum Speed Error: %.3f m/s\n', ...
    maxSpeedError);

fprintf('RMS Speed Error: %.3f m/s\n', ...
    rmsSpeedError);

fprintf('Final Speed Error: %.3f m/s\n', ...
    finalSpeedError);


%% ============================================================
% PRINT CONTROL COMMAND RESULTS
% ============================================================

fprintf('\n');

fprintf('----------------------------------------------------\n');
fprintf('CONTROL COMMAND VALIDATION\n');
fprintf('----------------------------------------------------\n');

fprintf('Maximum Steering Command: %.4f rad\n', ...
    maxSteeringCommand);

fprintf('Maximum Acceleration Command: %.4f m/s^2\n', ...
    maxAccelerationCommand);

fprintf('Maximum Deceleration Command: %.4f m/s^2\n', ...
    maxDecelerationCommand);


%% ============================================================
% PRINT FINAL VEHICLE STATE
% ============================================================

fprintf('\n');

fprintf('----------------------------------------------------\n');
fprintf('FINAL VEHICLE STATE\n');
fprintf('----------------------------------------------------\n');

fprintf('Final X Position: %.3f m\n', ...
    finalX);

fprintf('Final Y Position: %.3f m\n', ...
    finalY);

fprintf('Final Vehicle Speed: %.3f m/s\n', ...
    finalSpeed);

fprintf('Final Heading: %.4f rad\n', ...
    finalHeading);


%% ============================================================
% PRINT VALIDATION STATUS
% ============================================================

fprintf('\n');

fprintf('----------------------------------------------------\n');
fprintf('VALIDATION STATUS\n');
fprintf('----------------------------------------------------\n');


if pathPlanningPass

    fprintf('Hybrid A* Path Planning: PASS\n');

else

    fprintf('Hybrid A* Path Planning: FAIL\n');

end


if pathTrackingPass

    fprintf('Path Tracking: PASS\n');

else

    fprintf('Path Tracking: FAIL\n');

end


if speedTrackingPass

    fprintf('Speed Tracking: PASS\n');

else

    fprintf('Speed Tracking: FAIL\n');

end


if steeringLimitPass

    fprintf('Steering Command Limit: PASS\n');

else

    fprintf('Steering Command Limit: FAIL\n');

end


if accelerationLimitPass

    fprintf('Acceleration Limit: PASS\n');

else

    fprintf('Acceleration Limit: FAIL\n');

end


if decelerationLimitPass

    fprintf('Deceleration Limit: PASS\n');

else

    fprintf('Deceleration Limit: FAIL\n');

end


fprintf('\n');

fprintf('====================================================\n');

if overallPass

    fprintf('M6 INTEGRATED VALIDATION: PASS\n');

else

    fprintf('M6 INTEGRATED VALIDATION: FAIL\n');

end

fprintf('====================================================\n');


%% ============================================================
% INTEGRATED VALIDATION PLOTS
% ============================================================

figure;


%% Path Tracking

subplot(2,2,1)

plot(refX,refY,'k--','LineWidth',1.5)

hold on

plot(egoX,egoY,'r','LineWidth',1.5)

grid on

xlabel('X Position (m)')

ylabel('Y Position (m)')

title('M6 Integrated Path Tracking')

legend( ...
    'Reference Path', ...
    'Ego Vehicle Trajectory', ...
    'Location','best')


%% Cross Track Error

subplot(2,2,2)

plot(time,crossTrackError,'b','LineWidth',1.5)

grid on

xlabel('Time (s)')

ylabel('Cross-Track Error (m)')

title('Cross-Track Error')


%% Speed Tracking

subplot(2,2,3)

plot(time,egoSpeed,'b','LineWidth',1.5)

hold on

plot(time,targetSpeed,'r--','LineWidth',1.5)

grid on

xlabel('Time (s)')

ylabel('Speed (m/s)')

title('Longitudinal Speed Tracking')

legend( ...
    'Ego Speed', ...
    'Target Speed', ...
    'Location','best')


%% Control Commands

subplot(2,2,4)

plot(time,steeringCmd,'LineWidth',1.2)

hold on

plot(time,accelerationCmd,'LineWidth',1.2)

grid on

xlabel('Time (s)')

ylabel('Command')

title('Control Commands')

legend( ...
    'Steering Command', ...
    'Acceleration Command', ...
    'Location','best')


%% ============================================================
% END OF VALIDATION
% ============================================================