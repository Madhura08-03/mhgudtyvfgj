%% ============================================================
% M6_CreateMockInputs.m
%
% Creates a Simulink subsystem containing standalone mock inputs
% for PerceptionBus and DecisionBus.
% ============================================================

model = 'M6Execution';

%% Make sure the model is open
open_system(model);

%% Remove existing subsystem if it already exists
mockSubsystem = [model '/M6MockInputs'];

if getSimulinkBlockHandle(mockSubsystem) ~= -1
    delete_block(mockSubsystem);
end

%% Create subsystem
add_block('simulink/Ports & Subsystems/Subsystem', ...
    mockSubsystem, ...
    'Position',[1100 100 1350 250]);

%% Open subsystem
open_system(mockSubsystem);

%% ============================================================
% Remove default blocks inside subsystem
%% ============================================================

blocks = find_system(mockSubsystem, ...
    'SearchDepth',1, ...
    'Type','Block');

for k = 1:length(blocks)

    if ~strcmp(blocks{k},mockSubsystem)
        delete_block(blocks{k});
    end

end

%% ============================================================
% PERCEPTION MOCK INPUT
%% ============================================================

add_block('simulink/Sources/Constant', ...
    [mockSubsystem '/MockPerception'], ...
    'Value','mockPerception', ...
    'Position',[80 70 180 110]);

add_block('simulink/Ports & Subsystems/Out1', ...
    [mockSubsystem '/PerceptionBusOut'], ...
    'Position',[300 70 330 90]);

add_line(mockSubsystem, ...
    'MockPerception/1', ...
    'PerceptionBusOut/1');

%% ============================================================
% DECISION MOCK INPUT
%% ============================================================

add_block('simulink/Sources/Constant', ...
    [mockSubsystem '/MockDecision'], ...
    'Value','mockDecision', ...
    'Position',[80 170 180 210]);

add_block('simulink/Ports & Subsystems/Out1', ...
    [mockSubsystem '/DecisionBusOut'], ...
    'Position',[300 170 330 190]);

add_line(mockSubsystem, ...
    'MockDecision/1', ...
    'DecisionBusOut/1');


%% ============================================================
% Set output names
%% ============================================================

set_param( ...
    [mockSubsystem '/PerceptionBusOut'], ...
    'Port','1');

set_param( ...
    [mockSubsystem '/DecisionBusOut'], ...
    'Port','2');

%% ============================================================
% Explicit Bus Data Types
%% ============================================================

set_param( ...
    [mockSubsystem '/MockPerception'], ...
    'OutDataTypeStr', 'Bus: PerceptionBus');

set_param( ...
    [mockSubsystem '/MockDecision'], ...
    'OutDataTypeStr', 'Bus: DecisionBus');


%% ============================================================
% Save model
%% ============================================================

save_system(model);

disp('==============================================')
disp('M6 MOCK INPUT SUBSYSTEM CREATED SUCCESSFULLY')
disp('Outputs:')
disp('1 -> PerceptionBus')
disp('2 -> DecisionBus')
disp('==============================================')