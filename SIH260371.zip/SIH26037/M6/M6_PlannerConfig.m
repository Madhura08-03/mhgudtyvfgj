%% ============================================================
% M6_PlannerConfig.m
% Configuration for Hybrid A* Local Path Planner
%% ============================================================

plannerConfig = struct;

%% Grid / Map

plannerConfig.Resolution = 2;       % cells per meter
plannerConfig.XStep = 1.0;          % motion primitive length (m)

%% Vehicle Geometry

plannerConfig.Wheelbase = 2.7;      % meters
plannerConfig.MinTurningRadius = 5; % meters

% Maximum steering angle derived from turning radius
plannerConfig.MaxSteeringAngle = ...
    atan(plannerConfig.Wheelbase / ...
    plannerConfig.MinTurningRadius);

%% Heading Discretization

plannerConfig.NumHeadingBins = 72;

%% Motion primitives

plannerConfig.SteeringSamples = linspace( ...
    -plannerConfig.MaxSteeringAngle, ...
    plannerConfig.MaxSteeringAngle, ...
    7);

%% Planning limits

plannerConfig.MaxIterations = 50000;

plannerConfig.GoalTolerancePosition = 1.0; % m
plannerConfig.GoalToleranceHeading = deg2rad(15);

%% Cost parameters

plannerConfig.DistanceWeight = 1.0;
plannerConfig.TurnWeight = 0.2;
plannerConfig.ReverseWeight = 2.0;

%% Display

disp('==========================================')
disp('M6 HYBRID A* CONFIGURATION LOADED')
disp('==========================================')
disp(plannerConfig)