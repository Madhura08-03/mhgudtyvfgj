%% ============================================================
% M6_ControllerConfig.m
%
% Lateral and Longitudinal Controller Configuration
%% ============================================================

controllerConfig = struct;

%% ------------------------------------------------------------
% Stanley Lateral Controller
%% ------------------------------------------------------------

controllerConfig.StanleyGain = 1.5;

controllerConfig.MaxSteeringAngle = deg2rad(30);

%% ------------------------------------------------------------
% Longitudinal Controller
%% ------------------------------------------------------------

controllerConfig.SpeedGain = 1.0;

% Maximum allowed acceleration (m/s^2)
controllerConfig.MaxAcceleration = 3.0;

% Maximum allowed deceleration (m/s^2)
controllerConfig.MaxDeceleration = -5.0;

disp('==========================================')
disp('M6 CONTROLLER CONFIGURATION LOADED')
disp('==========================================')

disp(controllerConfig)