%% ============================================================
% SIH26037 / M6 INTEGRATION STARTUP
%
% Initializes:
%   1. MATLAB paths
%   2. Simulink Bus objects
%   3. Mock decision input
%   4. Mock perception input
%   5. Reference path
%
% ============================================================

clc;

%% ============================================================
% PROJECT PATHS
% ============================================================

m6Root = fileparts(mfilename('fullpath'));

functionsFolder = fullfile(m6Root,'Functions');

if ~isfolder(functionsFolder)
    functionsFolder = fullfile(m6Root,'functions');
end

addpath(m6Root);

if isfolder(functionsFolder)
    addpath(functionsFolder);
end


%% ============================================================
% VEHICLE STATE BUS
% ============================================================

VehicleStateBus = Simulink.Bus;

VehicleStateBus.Elements(1) = Simulink.BusElement;
VehicleStateBus.Elements(1).Name = 'EgoSpeed';
VehicleStateBus.Elements(1).DataType = 'double';
VehicleStateBus.Elements(1).Dimensions = 1;

VehicleStateBus.Elements(2) = Simulink.BusElement;
VehicleStateBus.Elements(2).Name = 'SteeringAngle';
VehicleStateBus.Elements(2).DataType = 'double';
VehicleStateBus.Elements(2).Dimensions = 1;

VehicleStateBus.Elements(3) = Simulink.BusElement;
VehicleStateBus.Elements(3).Name = 'EgoX';
VehicleStateBus.Elements(3).DataType = 'double';
VehicleStateBus.Elements(3).Dimensions = 1;

VehicleStateBus.Elements(4) = Simulink.BusElement;
VehicleStateBus.Elements(4).Name = 'EgoY';
VehicleStateBus.Elements(4).DataType = 'double';
VehicleStateBus.Elements(4).Dimensions = 1;

VehicleStateBus.Elements(5) = Simulink.BusElement;
VehicleStateBus.Elements(5).Name = 'HeadingAngle';
VehicleStateBus.Elements(5).DataType = 'double';
VehicleStateBus.Elements(5).Dimensions = 1;

VehicleStateBus.Elements(6) = Simulink.BusElement;
VehicleStateBus.Elements(6).Name = 'EgoPitch';
VehicleStateBus.Elements(6).DataType = 'double';
VehicleStateBus.Elements(6).Dimensions = 1;


%% ============================================================
% DECISION BUS
% ============================================================

DecisionBus = Simulink.Bus;

DecisionBus.Elements(1) = Simulink.BusElement;
DecisionBus.Elements(1).Name = 'ManeuverState';
DecisionBus.Elements(1).DataType = 'uint8';
DecisionBus.Elements(1).Dimensions = 1;

DecisionBus.Elements(2) = Simulink.BusElement;
DecisionBus.Elements(2).Name = 'TargetSpeed';
DecisionBus.Elements(2).DataType = 'double';
DecisionBus.Elements(2).Dimensions = 1;

DecisionBus.Elements(3) = Simulink.BusElement;
DecisionBus.Elements(3).Name = 'DecelCmd';
DecisionBus.Elements(3).DataType = 'double';
DecisionBus.Elements(3).Dimensions = 1;

DecisionBus.Elements(4) = Simulink.BusElement;
DecisionBus.Elements(4).Name = 'ReplanRequest';
DecisionBus.Elements(4).DataType = 'boolean';
DecisionBus.Elements(4).Dimensions = 1;


%% ============================================================
% PERCEPTION BUS
% ============================================================

PerceptionBus = Simulink.Bus;

PerceptionBus.Elements(1) = Simulink.BusElement;
PerceptionBus.Elements(1).Name = 'TargetIDs';
PerceptionBus.Elements(1).DataType = 'uint32';
PerceptionBus.Elements(1).Dimensions = [10 1];

PerceptionBus.Elements(2) = Simulink.BusElement;
PerceptionBus.Elements(2).Name = 'TargetPositions';
PerceptionBus.Elements(2).DataType = 'double';
PerceptionBus.Elements(2).Dimensions = [10 3];

PerceptionBus.Elements(3) = Simulink.BusElement;
PerceptionBus.Elements(3).Name = 'TargetVelocities';
PerceptionBus.Elements(3).DataType = 'double';
PerceptionBus.Elements(3).Dimensions = [10 2];

PerceptionBus.Elements(4) = Simulink.BusElement;
PerceptionBus.Elements(4).Name = 'ClassIDs';
PerceptionBus.Elements(4).DataType = 'uint8';
PerceptionBus.Elements(4).Dimensions = [10 1];

PerceptionBus.Elements(5) = Simulink.BusElement;
PerceptionBus.Elements(5).Name = 'PredictedPaths';
PerceptionBus.Elements(5).DataType = 'double';
PerceptionBus.Elements(5).Dimensions = [10 30 2];


%% ============================================================
% MOCK DECISION INPUT
% ============================================================

mockDecision = struct;

mockDecision.ManeuverState = uint8(3);
mockDecision.TargetSpeed = 8.3;
mockDecision.DecelCmd = 0;
mockDecision.ReplanRequest = false;


%% ============================================================
% MOCK PERCEPTION INPUT
% ============================================================

mockPerception = struct;

mockPerception.TargetIDs = zeros(10,1,'uint32');
mockPerception.TargetPositions = zeros(10,3);
mockPerception.TargetVelocities = zeros(10,2);
mockPerception.ClassIDs = zeros(10,1,'uint8');
mockPerception.PredictedPaths = zeros(10,30,2);


% Tractor

mockPerception.TargetIDs(1) = uint32(1);

mockPerception.TargetPositions(1,:) = [40 0 0];

mockPerception.TargetVelocities(1,:) = [4.17 0];

mockPerception.ClassIDs(1) = uint8(2);


% Cow

mockPerception.TargetIDs(2) = uint32(2);

mockPerception.TargetPositions(2,:) = [80 -1.5 0];

mockPerception.TargetVelocities(2,:) = [0 0];

mockPerception.ClassIDs(2) = uint8(3);


%% ============================================================
% LOAD BUS DEFINITIONS FILE IF AVAILABLE
%
% Keeps compatibility with the existing M6Execution model.
% ============================================================

busFile = fullfile(m6Root,'M6BusDefinitions.mat');

if isfile(busFile)

    load(busFile);

end


%% ============================================================
% LOAD REFERENCE PATH
% ============================================================

referencePathFile = fullfile( ...
    m6Root, ...
    'M6_ReferencePath.mat');

if isfile(referencePathFile)

    load(referencePathFile);

else

    loaderFile = fullfile( ...
        m6Root, ...
        'M6_LoadReferencePath.m');

    if isfile(loaderFile)

        run(loaderFile);

    end

end


%% ============================================================
% VERIFY REFERENCE PATH
% ============================================================

if exist('referencePath','var')

    activeReferencePath = referencePath;

elseif exist('path','var')

    activeReferencePath = path;

else

    warning( ...
        'Reference path was not loaded. Runtime replanning can create it.');

end


%% ============================================================
% DISPLAY
% ============================================================

fprintf('\n');

fprintf('====================================================\n');

fprintf('           M6 INTEGRATION INITIALIZATION\n');

fprintf('====================================================\n');

fprintf('M6 Root: %s\n',m6Root);

fprintf('Functions Folder: %s\n',functionsFolder);

fprintf('VehicleStateBus elements: %d\n', ...
    numel(VehicleStateBus.Elements));

fprintf('DecisionBus elements: %d\n', ...
    numel(DecisionBus.Elements));

fprintf('PerceptionBus elements: %d\n', ...
    numel(PerceptionBus.Elements));


if exist('referencePath','var')

    fprintf( ...
        'Reference path points: %d\n', ...
        length(referencePath.X));

end


fprintf('====================================================\n');

fprintf('      M6 INTEGRATION INITIALIZATION COMPLETE\n');

fprintf('====================================================\n');

disp('M6 runtime dependencies are loaded.');

disp('Integration inputs expected:');

disp('  - VehicleStateBus');

disp('  - DecisionBus');

disp('  - PerceptionBus');