function [referencePath, planningSuccess, plannerStats] = ...
    M6_RuntimeReplan(vehicleState, perception, goalState, ...
    plannerConfig, pathConfig)
% ============================================================
% M6_RuntimeReplan
%
% Runtime local replanning pipeline for M6.
%
% Pipeline:
%
% VehicleState
%       +
% PerceptionBus
%       ↓
% parsePerceptionBus
%       ↓
% buildLocalOccupancyMap
%       ↓
% Hybrid A*
%       ↓
% processReferencePath
%
%
% INPUTS:
%
% vehicleState
%   Structure containing:
%       EgoX
%       EgoY
%       HeadingAngle
%
% perception
%   Structure matching PerceptionBus.
%
% goalState
%   [X Y Heading]
%
% plannerConfig
%   Hybrid A* configuration.
%
% pathConfig
%   Reference path processing configuration.
%
%
% OUTPUTS:
%
% referencePath
%   Processed path structure containing:
%       X
%       Y
%       Heading
%       Curvature
%       TargetSpeed
%       PathDistance
%
% planningSuccess
%   True if Hybrid A* successfully generates a path.
%
% plannerStats
%   Planning performance statistics.
%
% ============================================================


%% ============================================================
% DEFAULT OUTPUTS
% ============================================================

referencePath = struct( ...
    'X', [], ...
    'Y', [], ...
    'Heading', [], ...
    'Curvature', [], ...
    'TargetSpeed', [], ...
    'PathDistance', []);

planningSuccess = false;

plannerStats = struct( ...
    'Iterations', 0, ...
    'NodesExpanded', 0, ...
    'PlanningTime', 0);


%% ============================================================
% EXTRACT EGO STATE
% ============================================================

egoState = [ ...
    vehicleState.EgoX ...
    vehicleState.EgoY ...
    vehicleState.HeadingAngle];


%% ============================================================
% PARSE PERCEPTION DATA
% ============================================================

obstacles = parsePerceptionBus(perception);


%% ============================================================
% BUILD LOCAL OCCUPANCY MAP
% ============================================================

[occMap, mapInfo] = ...
    buildLocalOccupancyMap( ...
    egoState, ...
    obstacles);


%% ============================================================
% RUN HYBRID A* PLANNER
% ============================================================

[rawPath, planningSuccess, plannerStats] = ...
    planHybridAStar( ...
    occMap, ...
    mapInfo, ...
    egoState, ...
    goalState, ...
    plannerConfig);


%% ============================================================
% PROCESS SUCCESSFUL PATH
% ============================================================

if planningSuccess && ...
        ~isempty(rawPath)

    referencePath = ...
        processReferencePath( ...
        rawPath, ...
        pathConfig);

    % --------------------------------------------------------
    % Normalize path for existing Simulink interface.
    %
    % ReferencePathManager expects [1 x 61] path signals.
    % --------------------------------------------------------

    referencePath = ...
        M6_NormalizeReferencePath( ...
        referencePath, ...
        61);

end


end