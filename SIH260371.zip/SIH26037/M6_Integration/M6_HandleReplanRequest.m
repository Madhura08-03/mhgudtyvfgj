function [replanSuccess, plannerStats] = ...
    M6_HandleReplanRequest(goalState)
% ============================================================
% M6_HandleReplanRequest
%
% Executes runtime replanning and updates the active reference
% path used by the M6Execution model.
%
% PIPELINE:
%
% Replan Request
%       ↓
% Get Vehicle State
%       +
% Get Perception Data
%       ↓
% M6_RuntimeReplan
%       ↓
% Update activeReferencePath
%
% INPUT:
%
% goalState
%   [X Y Heading]
%
% OUTPUT:
%
% replanSuccess
%   True when a new valid reference path is generated.
%
% plannerStats
%   Hybrid A* planning performance statistics.
%
% ============================================================


%% ============================================================
% DEFAULT OUTPUTS
% ============================================================

replanSuccess = false;

plannerStats = struct( ...
    'Iterations', 0, ...
    'NodesExpanded', 0, ...
    'PlanningTime', 0);


%% ============================================================
% LOAD PLANNER CONFIGURATION
% ============================================================

if evalin( ...
        'base', ...
        'exist(''plannerConfig'',''var'')')

    plannerConfig = ...
        evalin( ...
        'base', ...
        'plannerConfig');

else

    error( ...
        'plannerConfig does not exist. ' + ...
        'Run M6_PlannerConfig.m first.');

end


%% ============================================================
% LOAD PATH PROCESSING CONFIGURATION
%
% Supports the configuration variable name used by the project.
% ============================================================

if evalin( ...
        'base', ...
        'exist(''pathProcessingConfig'',''var'')')

    pathConfig = ...
        evalin( ...
        'base', ...
        'pathProcessingConfig');

elseif evalin( ...
        'base', ...
        'exist(''pathConfig'',''var'')')

    pathConfig = ...
        evalin( ...
        'base', ...
        'pathConfig');

else

    error( ...
        'Path processing configuration not found. ' + ...
        'Run M6_PathProcessingConfig.m first.');

end


%% ============================================================
% LOAD PERCEPTION INPUT
% ============================================================

if evalin( ...
        'base', ...
        'exist(''mockPerception'',''var'')')

    perception = ...
        evalin( ...
        'base', ...
        'mockPerception');

else

    error( ...
        'mockPerception does not exist. ' + ...
        'Run startup first.');

end


%% ============================================================
% INITIALIZE VEHICLE STATE
% ============================================================

vehicleState = struct;


%% ============================================================
% GET EGO X POSITION
% ============================================================

if evalin( ...
        'base', ...
        'exist(''runtimeEgoX'',''var'')')

    vehicleState.EgoX = ...
        evalin( ...
        'base', ...
        'runtimeEgoX');

else

    vehicleState.EgoX = 0;

end


%% ============================================================
% GET EGO Y POSITION
% ============================================================

if evalin( ...
        'base', ...
        'exist(''runtimeEgoY'',''var'')')

    vehicleState.EgoY = ...
        evalin( ...
        'base', ...
        'runtimeEgoY');

else

    vehicleState.EgoY = 0;

end


%% ============================================================
% GET EGO HEADING
% ============================================================

if evalin( ...
        'base', ...
        'exist(''runtimeHeading'',''var'')')

    vehicleState.HeadingAngle = ...
        evalin( ...
        'base', ...
        'runtimeHeading');

else

    vehicleState.HeadingAngle = 0;

end


%% ============================================================
% DISPLAY REPLAN REQUEST
% ============================================================

fprintf('\n');

fprintf('==========================================\n');

fprintf('M6 RUNTIME REPLAN REQUEST\n');

fprintf('==========================================\n');

fprintf( ...
    'Vehicle Position: [%.2f %.2f]\n', ...
    vehicleState.EgoX, ...
    vehicleState.EgoY);

fprintf( ...
    'Heading: %.3f rad\n', ...
    vehicleState.HeadingAngle);


%% ============================================================
% EXECUTE RUNTIME REPLANNING
% ============================================================

[newReferencePath, ...
    replanSuccess, ...
    plannerStats] = ...
    M6_RuntimeReplan( ...
    vehicleState, ...
    perception, ...
    goalState, ...
    plannerConfig, ...
    pathConfig);


%% ============================================================
% UPDATE ACTIVE REFERENCE PATH
% ============================================================

if replanSuccess

    assignin( ...
        'base', ...
        'activeReferencePath', ...
        newReferencePath);


    %% ========================================================
    % DISPLAY SUCCESS
    %% ========================================================

    fprintf('\n');

    fprintf('==========================================\n');

    fprintf( ...
        'NEW ACTIVE REFERENCE PATH GENERATED\n');

    fprintf('==========================================\n');

    fprintf( ...
        'Path Points: %d\n', ...
        length(newReferencePath.X));

    fprintf( ...
        'Planning Time: %.4f s\n', ...
        plannerStats.PlanningTime);

    fprintf( ...
        'Active reference path updated.\n');


else

    %% ========================================================
    % DISPLAY FAILURE
    %% ========================================================

    warning( ...
        'M6 runtime replanning failed. ' + ...
        'Previous active path retained.');

end


end