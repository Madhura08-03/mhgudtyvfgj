function y = M6_SimulinkRuntimeReplan(u)

% ============================================================
% M6 SIMULINK RUNTIME REPLAN WRAPPER
% ============================================================

% Default output
y = 0;

% Execute replanning only when requested
if u ~= 0

    success = M6_ExecuteRuntimeReplan(1);

    if success
        y = 1;
    end

end

end