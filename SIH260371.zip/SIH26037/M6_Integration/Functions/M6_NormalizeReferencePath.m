function normalizedPath = M6_NormalizeReferencePath( ...
    referencePath, numPoints)
% ============================================================
% M6_NormalizeReferencePath
%
% Converts a reference path to a fixed number of points for
% Simulink integration.
%
% INPUT:
%   referencePath
%       Structure containing:
%       X
%       Y
%       Heading
%       Curvature
%       TargetSpeed
%       PathDistance
%
%   numPoints
%       Required number of output path points.
%
% OUTPUT:
%   normalizedPath
%       Reference path with exactly numPoints points.
%
% ============================================================


%% ============================================================
% DEFAULT OUTPUT
%% ============================================================

normalizedPath = struct( ...
    'X', zeros(numPoints,1), ...
    'Y', zeros(numPoints,1), ...
    'Heading', zeros(numPoints,1), ...
    'Curvature', zeros(numPoints,1), ...
    'TargetSpeed', zeros(numPoints,1), ...
    'PathDistance', zeros(numPoints,1));


%% ============================================================
% VALIDATE INPUT
%% ============================================================

if isempty(referencePath) || ...
        ~isfield(referencePath,'X') || ...
        isempty(referencePath.X)

    return

end


%% ============================================================
% CONVERT INPUTS TO COLUMN VECTORS
%% ============================================================

x = referencePath.X(:);

y = referencePath.Y(:);

heading = referencePath.Heading(:);

speed = referencePath.TargetSpeed(:);


%% ============================================================
% PATH LENGTH
%% ============================================================

numInputPoints = length(x);


%% ============================================================
% HANDLE SINGLE POINT PATH
%% ============================================================

if numInputPoints == 1

    normalizedPath.X(:) = x(1);

    normalizedPath.Y(:) = y(1);

    normalizedPath.Heading(:) = heading(1);

    normalizedPath.TargetSpeed(:) = speed(1);

    return

end


%% ============================================================
% INPUT PATH PARAMETER
%% ============================================================

inputParameter = linspace( ...
    0, ...
    1, ...
    numInputPoints)';


%% ============================================================
% OUTPUT PATH PARAMETER
%% ============================================================

outputParameter = linspace( ...
    0, ...
    1, ...
    numPoints)';


%% ============================================================
% RESAMPLE X
%% ============================================================

normalizedPath.X = interp1( ...
    inputParameter, ...
    x, ...
    outputParameter, ...
    'linear');


%% ============================================================
% RESAMPLE Y
%% ============================================================

normalizedPath.Y = interp1( ...
    inputParameter, ...
    y, ...
    outputParameter, ...
    'linear');


%% ============================================================
% RESAMPLE HEADING
%
% Unwrap before interpolation to avoid jumps around ±pi.
%% ============================================================

headingUnwrapped = unwrap(heading);

normalizedPath.Heading = interp1( ...
    inputParameter, ...
    headingUnwrapped, ...
    outputParameter, ...
    'linear');

normalizedPath.Heading = atan2( ...
    sin(normalizedPath.Heading), ...
    cos(normalizedPath.Heading));


%% ============================================================
% RESAMPLE TARGET SPEED
%% ============================================================

normalizedPath.TargetSpeed = interp1( ...
    inputParameter, ...
    speed, ...
    outputParameter, ...
    'linear');


%% ============================================================
% CURVATURE
%% ============================================================

if isfield(referencePath,'Curvature') && ...
        ~isempty(referencePath.Curvature)

    curvature = referencePath.Curvature(:);

    normalizedPath.Curvature = interp1( ...
        inputParameter, ...
        curvature, ...
        outputParameter, ...
        'linear');

end


%% ============================================================
% PATH DISTANCE
%% ============================================================

segmentDistance = sqrt( ...
    diff(normalizedPath.X).^2 + ...
    diff(normalizedPath.Y).^2);

normalizedPath.PathDistance = [ ...
    0
    cumsum(segmentDistance)];


end