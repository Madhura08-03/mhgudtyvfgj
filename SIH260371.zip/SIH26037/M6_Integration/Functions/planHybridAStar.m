function [path, success, plannerStats] = planHybridAStar( ...
    occMap, mapInfo, startState, goalState, plannerConfig)
% ============================================================
% OPTIMIZED HYBRID A* LOCAL PATH PLANNER
%
% State: [x y heading]
%
% Optimizations:
%   1. Numeric arrays instead of growing struct arrays
%   2. Preallocated node storage
%   3. Faster open-list handling
%   4. Reduced repeated field access
% ============================================================

tStart = tic;

success = false;
path = [];

plannerStats = struct( ...
    'Iterations', 0, ...
    'NodesExpanded', 0, ...
    'PlanningTime', 0);

%% ============================================================
% CONFIGURATION
% ============================================================

stepLength = plannerConfig.XStep;
wheelbase = plannerConfig.Wheelbase;
steeringSamples = plannerConfig.SteeringSamples;

maxIterations = plannerConfig.MaxIterations;
numHeadingBins = plannerConfig.NumHeadingBins;

positionTolerance = plannerConfig.GoalTolerancePosition;
headingTolerance = plannerConfig.GoalToleranceHeading;

turnWeight = plannerConfig.TurnWeight;

[numRows, numCols] = size(occMap);

numSteeringSamples = length(steeringSamples);


%% ============================================================
% BEST COST STORAGE
% ============================================================

bestCost = inf( ...
    numRows, ...
    numCols, ...
    numHeadingBins);


%% ============================================================
% PREALLOCATED NODE STORAGE
%
% Columns:
%   1 = X
%   2 = Y
%   3 = Heading
% ============================================================

nodeStates = zeros(maxIterations + 1, 3);

nodeParent = zeros( ...
    maxIterations + 1, ...
    1);

nodeG = inf( ...
    maxIterations + 1, ...
    1);

nodeF = inf( ...
    maxIterations + 1, ...
    1);


%% ============================================================
% START POSITION
% ============================================================

startRow = floor( ...
    (startState(2) - mapInfo.OriginY) * ...
    mapInfo.Resolution) + 1;

startCol = floor( ...
    (startState(1) - mapInfo.OriginX) * ...
    mapInfo.Resolution) + 1;


%% ============================================================
% CHECK START POSITION
% ============================================================

if startRow < 1 || ...
   startRow > numRows || ...
   startCol < 1 || ...
   startCol > numCols

    plannerStats.PlanningTime = toc(tStart);

    return

end


%% ============================================================
% START HEADING BIN
% ============================================================

startHeadingBin = localHeadingBin( ...
    startState(3), ...
    numHeadingBins);


%% ============================================================
% INITIALIZE START NODE
% ============================================================

nodeCount = 1;

nodeStates(1,:) = startState;

nodeParent(1) = 0;

nodeG(1) = 0;

startH = localHeuristic( ...
    startState, ...
    goalState);

nodeF(1) = startH;


bestCost( ...
    startRow, ...
    startCol, ...
    startHeadingBin) = 0;


%% ============================================================
% OPEN LIST
%
% Stores node indices.
% ============================================================

openList = zeros( ...
    maxIterations + 1, ...
    1);

openF = inf( ...
    maxIterations + 1, ...
    1);

openCount = 1;

openList(1) = 1;

openF(1) = nodeF(1);


goalNodeIndex = 0;


%% ============================================================
% HYBRID A* SEARCH
% ============================================================

while openCount > 0 && ...
      plannerStats.Iterations < maxIterations


    plannerStats.Iterations = ...
        plannerStats.Iterations + 1;


    %% ========================================================
    % FIND LOWEST F COST
    % ========================================================

    [~, bestIndex] = ...
        min(openF(1:openCount));


    currentIndex = ...
        openList(bestIndex);


    %% ========================================================
    % REMOVE FROM OPEN LIST
    %
    % Swap with final entry instead of shifting array.
    % ========================================================

    openList(bestIndex) = ...
        openList(openCount);

    openF(bestIndex) = ...
        openF(openCount);

    openCount = ...
        openCount - 1;


    %% ========================================================
    % CURRENT STATE
    % ========================================================

    currentState = ...
        nodeStates(currentIndex,:);

    currentG = ...
        nodeG(currentIndex);


    plannerStats.NodesExpanded = ...
        plannerStats.NodesExpanded + 1;


    %% ========================================================
    % GOAL CHECK
    % ========================================================

    dxGoal = ...
        currentState(1) - goalState(1);

    dyGoal = ...
        currentState(2) - goalState(2);

    positionError = ...
        sqrt(dxGoal^2 + dyGoal^2);


    headingDifference = ...
        atan2( ...
        sin(currentState(3) - goalState(3)), ...
        cos(currentState(3) - goalState(3)));

    headingError = ...
        abs(headingDifference);


    if positionError <= positionTolerance && ...
       headingError <= headingTolerance

        success = true;

        goalNodeIndex = currentIndex;

        break

    end


    %% ========================================================
    % EXPAND STEERING PRIMITIVES
    % ========================================================

    x = currentState(1);
    y = currentState(2);
    heading = currentState(3);


    cosHeading = cos(heading);

    sinHeading = sin(heading);


    for s = 1:numSteeringSamples


        steering = ...
            steeringSamples(s);


        %% ====================================================
        % PROPAGATE STATE
        % ====================================================

        nextHeading = ...
            heading + ...
            stepLength * ...
            tan(steering) / ...
            wheelbase;


        nextHeading = ...
            atan2( ...
            sin(nextHeading), ...
            cos(nextHeading));


        nextX = ...
            x + ...
            stepLength * ...
            cosHeading;


        nextY = ...
            y + ...
            stepLength * ...
            sinHeading;


        %% ====================================================
        % GRID CONVERSION
        % ====================================================

        nextCol = floor( ...
            (nextX - mapInfo.OriginX) * ...
            mapInfo.Resolution) + 1;


        nextRow = floor( ...
            (nextY - mapInfo.OriginY) * ...
            mapInfo.Resolution) + 1;


        %% ====================================================
        % BOUNDARY CHECK
        % ====================================================

        if nextRow < 1 || ...
           nextRow > numRows || ...
           nextCol < 1 || ...
           nextCol > numCols

            continue

        end


        %% ====================================================
        % COLLISION CHECK
        % ====================================================

        if occMap(nextRow,nextCol) > 0.5

            continue

        end


        %% ====================================================
        % HEADING BIN
        % ====================================================

        headingNormalized = ...
            (nextHeading + pi) / ...
            (2*pi);


        nextHeadingBin = ...
            floor( ...
            headingNormalized * ...
            numHeadingBins) + 1;


        if nextHeadingBin < 1

            nextHeadingBin = 1;

        elseif nextHeadingBin > numHeadingBins

            nextHeadingBin = ...
                numHeadingBins;

        end


        %% ====================================================
        % COST
        % ====================================================

        turnCost = ...
            abs(steering) * ...
            turnWeight;


        gNew = ...
            currentG + ...
            stepLength + ...
            turnCost;


        %% ====================================================
        % BEST COST CHECK
        % ====================================================

        if gNew >= ...
                bestCost( ...
                nextRow, ...
                nextCol, ...
                nextHeadingBin)

            continue

        end


        bestCost( ...
            nextRow, ...
            nextCol, ...
            nextHeadingBin) = ...
            gNew;


        %% ====================================================
        % HEURISTIC
        % ====================================================

        dx = ...
            nextX - goalState(1);

        dy = ...
            nextY - goalState(2);


        positionDistance = ...
            sqrt(dx^2 + dy^2);


        headingDiff = ...
            abs( ...
            atan2( ...
            sin(nextHeading - goalState(3)), ...
            cos(nextHeading - goalState(3))));


        hNew = ...
            positionDistance + ...
            0.5 * headingDiff;


        fNew = ...
            gNew + hNew;


        %% ====================================================
        % ADD NODE
        % ====================================================

        nodeCount = ...
            nodeCount + 1;


        % Safety check

        if nodeCount > ...
                maxIterations + 1

            break

        end


        nodeStates(nodeCount,:) = ...
            [nextX nextY nextHeading];


        nodeParent(nodeCount) = ...
            currentIndex;


        nodeG(nodeCount) = ...
            gNew;


        nodeF(nodeCount) = ...
            fNew;


        %% ====================================================
        % ADD TO OPEN LIST
        % ====================================================

        openCount = ...
            openCount + 1;


        openList(openCount) = ...
            nodeCount;


        openF(openCount) = ...
            fNew;


    end


end


%% ============================================================
% PATH RECONSTRUCTION
% ============================================================

if success


    indices = zeros( ...
        nodeCount, ...
        1);

    count = 0;

    currentIndex = ...
        goalNodeIndex;


    while currentIndex ~= 0

        count = ...
            count + 1;


        indices(count) = ...
            currentIndex;


        currentIndex = ...
            nodeParent(currentIndex);

    end


    indices = ...
        flipud(indices(1:count));


    path = ...
        nodeStates(indices,:);


end


%% ============================================================
% PLANNING TIME
% ============================================================

plannerStats.PlanningTime = ...
    toc(tStart);


end


%% ============================================================
% LOCAL FUNCTION
% HEADING BIN
% ============================================================

function headingBin = ...
    localHeadingBin( ...
    heading, ...
    numHeadingBins)


heading = ...
    atan2( ...
    sin(heading), ...
    cos(heading));


headingNormalized = ...
    (heading + pi) / ...
    (2*pi);


headingBin = ...
    floor( ...
    headingNormalized * ...
    numHeadingBins) + 1;


headingBin = ...
    max( ...
    1, ...
    min( ...
    numHeadingBins, ...
    headingBin));


end


%% ============================================================
% LOCAL FUNCTION
% HEURISTIC
% ============================================================

function h = ...
    localHeuristic( ...
    state, ...
    goalState)


dx = ...
    state(1) - ...
    goalState(1);


dy = ...
    state(2) - ...
    goalState(2);


positionDistance = ...
    sqrt(dx^2 + dy^2);


headingDifference = ...
    abs( ...
    atan2( ...
    sin(state(3) - goalState(3)), ...
    cos(state(3) - goalState(3))));


h = ...
    positionDistance + ...
    0.5 * headingDifference;


end