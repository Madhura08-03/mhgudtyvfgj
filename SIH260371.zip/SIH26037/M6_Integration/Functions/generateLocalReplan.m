function [referencePath, success, plannerStats] = ...
    generateLocalReplan(vehicleState, perception, goalState, ...
    plannerConfig, pathConfig)

% ============================================================
% generateLocalReplan
%
% Integration function connecting:
%
% VehicleState
%       ↓
% PerceptionBus
%       ↓
% parsePerceptionBus
%       ↓
% buildLocalOccupancyMap
%       ↓
% Hybrid A*
%       ↓
% processReferencePath
%
% ============================================================


%% ============================================================
% EXTRACT EGO STATE
% ============================================================

egoState = [ ...
    vehicleState.EgoX ...
    vehicleState.EgoY ...
    vehicleState.HeadingAngle];


%% ============================================================
% PARSE PERCEPTION DATA
% ============================================================

obstacles = parsePerceptionBus(perception);


%% ============================================================
% BUILD LOCAL OCCUPANCY MAP
% ============================================================

[occMap, mapInfo] = ...
    buildLocalOccupancyMap( ...
    egoState, ...
    obstacles);


%% ============================================================
% RUN HYBRID A*
% ============================================================

[path, success, plannerStats] = ...
    planHybridAStar( ...
    occMap, ...
    mapInfo, ...
    egoState, ...
    goalState, ...
    plannerConfig);


%% ============================================================
% PROCESS PATH
% ============================================================

if success

    referencePath = ...
        processReferencePath( ...
        path, ...
        pathConfig);

else

    referencePath = struct( ...
        'X', [], ...
        'Y', [], ...
        'Heading', [], ...
        'Curvature', [], ...
        'TargetSpeed', [], ...
        'PathDistance', []);

end


end