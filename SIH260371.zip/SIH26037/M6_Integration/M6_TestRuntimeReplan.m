%% ============================================================
% M6_TestRuntimeReplan
%
% Validation for M6_RuntimeReplan
%% ============================================================

clc;


%% ============================================================
% INITIALIZE M6
%% ============================================================

startup


%% ============================================================
% CREATE MOCK PERCEPTION ENVIRONMENT
%% ============================================================

M6_CreateMockEnvironment


%% ============================================================
% DEFINE EGO VEHICLE STATE
%% ============================================================

vehicleState = struct;

vehicleState.EgoX = 0;

vehicleState.EgoY = 0;

vehicleState.HeadingAngle = 0;


%% ============================================================
% DEFINE GOAL STATE
%% ============================================================

goalState = [100 0 0];


%% ============================================================
% RUN RUNTIME REPLANNING PIPELINE
%% ============================================================

[referencePath, planningSuccess, plannerStats] = ...
    M6_RuntimeReplan( ...
    vehicleState, ...
    mockPerception, ...
    goalState, ...
    plannerConfig, ...
    pathConfig);


%% ============================================================
% DISPLAY RESULTS
%% ============================================================

fprintf('\n');

fprintf('==========================================\n');

fprintf('M6 RUNTIME REPLANNING TEST\n');

fprintf('==========================================\n');

fprintf('Planning Success: %d\n', ...
    planningSuccess);

fprintf('Planning Time: %.4f s\n', ...
    plannerStats.PlanningTime);

fprintf('Iterations: %d\n', ...
    plannerStats.Iterations);

fprintf('Nodes Expanded: %d\n', ...
    plannerStats.NodesExpanded);


if planningSuccess

    fprintf('Reference Path Points: %d\n', ...
        length(referencePath.X));

else

    fprintf('Reference Path: NOT GENERATED\n');

end


%% ============================================================
% PLOT RESULT
%% ============================================================

if planningSuccess

    figure;

    plot( ...
        referencePath.X, ...
        referencePath.Y, ...
        'LineWidth', ...
        1.5);

    hold on;

    plot( ...
        vehicleState.EgoX, ...
        vehicleState.EgoY, ...
        'o', ...
        'MarkerSize', ...
        8);

    plot( ...
        goalState(1), ...
        goalState(2), ...
        'x', ...
        'MarkerSize', ...
        10, ...
        'LineWidth', ...
        2);

    grid on;

    xlabel('X Position (m)');

    ylabel('Y Position (m)');

    title('M6 Runtime Replanned Reference Path');

    legend( ...
        'Replanned Path', ...
        'Ego Vehicle', ...
        'Goal', ...
        'Location', ...
        'best');

end