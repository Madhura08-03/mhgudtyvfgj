function planningSuccess = M6_ExecuteRuntimeReplan(triggerSignal)
% ============================================================
% M6_ExecuteRuntimeReplan
%
% Executes runtime reference path replanning.
%
% Input:
% triggerSignal - Dummy signal used to trigger execution.
%
% Output:
% planningSuccess - True if runtime replanning succeeds.
%
% ============================================================

planningSuccess = false;

% Dummy trigger input
if nargin < 1
    triggerSignal = 1;
end

% Keep triggerSignal referenced
triggerSignal = triggerSignal;

% ============================================================
% CHECK REQUIRED VARIABLES
% ============================================================

if ~evalin('base', 'exist(''plannerConfig'', ''var'')')
    error('plannerConfig does not exist. Run startup first.');
end

if ~evalin('base', 'exist(''pathProcessingConfig'', ''var'')')
    error('pathProcessingConfig does not exist. Run startup first.');
end

if ~evalin('base', 'exist(''mockPerception'', ''var'')')
    error('mockPerception does not exist. Run startup first.');
end

% ============================================================
% LOAD CONFIGURATION
% ============================================================

plannerConfig = evalin('base', 'plannerConfig');

pathProcessingConfig = ...
    evalin('base', 'pathProcessingConfig');

perception = evalin('base', 'mockPerception');

% ============================================================
% CREATE CURRENT VEHICLE STATE
% ============================================================

vehicleState = struct;

vehicleState.EgoX = 0;
vehicleState.EgoY = 0;
vehicleState.HeadingAngle = 0;

vehicleState.EgoSpeed = 0;
vehicleState.SteeringAngle = 0;
vehicleState.EgoPitch = 0;

% ============================================================
% GET GOAL STATE
% ============================================================

if evalin('base', 'exist(''activeReferencePath'', ''var'')')

    activeReferencePath = ...
        evalin('base', 'activeReferencePath');

    goalState = [ ...
        activeReferencePath.X(end), ...
        activeReferencePath.Y(end), ...
        activeReferencePath.Heading(end)];

else

    goalState = [100, 0, 0];

end

% ============================================================
% DISPLAY REPLAN EVENT
% ============================================================

fprintf('\n');
fprintf('====================================================\n');
fprintf('M6 RUNTIME REPLAN REQUEST RECEIVED\n');
fprintf('====================================================\n');

% ============================================================
% EXECUTE RUNTIME REPLANNING
% ============================================================

[referencePath, planningSuccess, plannerStats] = ...
    M6_RuntimeReplan( ...
        vehicleState, ...
        perception, ...
        goalState, ...
        plannerConfig, ...
        pathProcessingConfig);

% ============================================================
% UPDATE ACTIVE REFERENCE PATH
% ============================================================

if planningSuccess

    assignin( ...
        'base', ...
        'activeReferencePath', ...
        referencePath);

    assignin( ...
        'base', ...
        'lastPlannerStats', ...
        plannerStats);

    fprintf('RUNTIME REPLAN SUCCESSFUL\n');

    fprintf( ...
        'Path Points: %d\n', ...
        length(referencePath.X));

    fprintf( ...
        'Planning Time: %.4f seconds\n', ...
        plannerStats.PlanningTime);

else

    fprintf('RUNTIME REPLAN FAILED\n');

end

fprintf('====================================================\n');

end
