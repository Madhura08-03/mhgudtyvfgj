%% ============================================================
% M6_TestPerceptionReplan
%
% Standalone test of:
%
% Perception
% → Occupancy Map
% → Hybrid A*
% → Reference Path
%
% ============================================================

clc;


%% ============================================================
% INITIALIZE M6
% ============================================================

startup


%% ============================================================
% CREATE MOCK ENVIRONMENT
% ============================================================

M6_CreateMockEnvironment

%% ============================================================
% CURRENT EGO VEHICLE STATE
% ============================================================

vehicleState.EgoX = 0;

vehicleState.EgoY = 0;

vehicleState.HeadingAngle = 0;


%% ============================================================
% GOAL STATE
% ============================================================

goalState = [ ...
    100 ...
    0 ...
    0];


%% ============================================================
% GENERATE LOCAL REPLAN
% ============================================================

[localReferencePath, success, plannerStats] = ...
    generateLocalReplan( ...
    vehicleState, ...
    mockPerception, ...
    goalState, ...
    plannerConfig, ...
    pathConfig);


%% ============================================================
% RESULTS
% ============================================================

fprintf('\n');

fprintf('==========================================\n');

fprintf('M6 PERCEPTION → REPLANNING TEST\n');

fprintf('==========================================\n');


fprintf('Planning Success: %d\n',success);

fprintf('Planning Time: %.4f s\n', ...
    plannerStats.PlanningTime);

fprintf('Iterations: %d\n', ...
    plannerStats.Iterations);

fprintf('Nodes Expanded: %d\n', ...
    plannerStats.NodesExpanded);


%% ============================================================
% VISUALIZE RESULT
% ============================================================

if success

    figure;

    plot( ...
        localReferencePath.X, ...
        localReferencePath.Y, ...
        'b-', ...
        'LineWidth',2);

    hold on;

    % Plot obstacles

    obstacles = ...
        parsePerceptionBus( ...
        mockPerception);

    for i = 1:length(obstacles)

        plot( ...
            obstacles(i).Position(1), ...
            obstacles(i).Position(2), ...
            'ro', ...
            'MarkerSize',10, ...
            'LineWidth',2);

    end


    plot( ...
        vehicleState.EgoX, ...
        vehicleState.EgoY, ...
        'go', ...
        'MarkerSize',10, ...
        'LineWidth',2);


    grid on;

    axis equal;

    xlabel('X Position (m)');

    ylabel('Y Position (m)');

    title('M6 Perception-Based Local Replanning');


    legend( ...
        'Replanned Path', ...
        'Detected Obstacles', ...
        'Ego Vehicle', ...
        'Location','best');

end