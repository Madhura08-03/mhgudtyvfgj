%% ============================================================
% M6_PlannerConfig.m
% Configuration for Hybrid A* Local Path Planner
%% ============================================================

plannerConfig = struct;


%% ============================================================
% GRID / MAP
%% ============================================================

plannerConfig.Resolution = 2;       % cells per meter
plannerConfig.XStep = 1.0;          % motion primitive length (m)


%% ============================================================
% VEHICLE GEOMETRY
%% ============================================================

plannerConfig.Wheelbase = 2.7;      % meters
plannerConfig.MinTurningRadius = 5; % meters


% Maximum steering angle derived from turning radius

plannerConfig.MaxSteeringAngle = ...
    atan( ...
    plannerConfig.Wheelbase / ...
    plannerConfig.MinTurningRadius);


%% ============================================================
% HEADING DISCRETIZATION
%
% Reduced from 72 to 36 bins for faster planning
%% ============================================================

plannerConfig.NumHeadingBins = 36;


%% ============================================================
% MOTION PRIMITIVES
%
% Reduced from 7 to 5 steering samples
%% ============================================================

plannerConfig.SteeringSamples = linspace( ...
    -plannerConfig.MaxSteeringAngle, ...
     plannerConfig.MaxSteeringAngle, ...
     5);


%% ============================================================
% PLANNING LIMITS
%
% Reduced maximum iterations for faster replanning
%% ============================================================

plannerConfig.MaxIterations = 20000;

plannerConfig.GoalTolerancePosition = 1.0; % m

plannerConfig.GoalToleranceHeading = ...
    deg2rad(15);


%% ============================================================
% COST PARAMETERS
%% ============================================================

plannerConfig.DistanceWeight = 1.0;

plannerConfig.TurnWeight = 0.2;

plannerConfig.ReverseWeight = 2.0;


%% ============================================================
% DISPLAY
%% ============================================================

disp('==========================================')

disp('M6 HYBRID A* CONFIGURATION LOADED')

disp('==========================================')

disp(plannerConfig)